<?php

//$keyId = 'rzp_test_Bh0KzXk8zovF39';
//$keySecret = 'FWLdqBzQSqmbY0GgF7jKh6zK';
$keyId = 'rzp_test_6loqHUgqJTKScP';
$keySecret = 'wwH6EvDQfPJDf1w4fELiM4hE';
$displayCurrency = 'INR';



//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);
