<?php
include("includes/header1.php");
include("functions/functions.php");
$active='Account';

?>

<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

   <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
           <div class="col-md-12"><!-- col-md-12 Begin -->
               
               <ul class="breadcrumb"><!-- breadcrumb Begin -->
                   <li>
                       <a href="index.php">Home</a>
                   </li>
                   <li>
                       Register
                   </li>
               </ul><!-- breadcrumb Finish -->
               
           </div><!-- col-md-12 Finish -->
           
          
           
           <div class="col-md-9"><!-- col-md-9 Begin -->
               
               <div class="box"><!-- box Begin -->
                   
                   <div class="box-header"><!-- box-header Begin -->
                       
                       <center><!-- center Begin -->
                           
                           <h2>Create new account</h2>
                           
                       </center><!-- center Finish -->
                      
                       <form action="customer_register.php" method="post" enctype="multipart/form-data" id="myform" ><!-- form Begin -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label> Name</label>
                               
                               <input type="text" class="form-control" name="c_name" required pattern="^[a-zA-Z0-9_.-]*$">
                               
                           </div><!-- form-group Finish -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label> Email</label>
                               
                               <input type="text" class="form-control" name="email" required>
                               
                           </div><!-- form-group Finish -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label>Password</label>
                               
                               <input type="password" class="form-control" name="c_pass1"  id="p1"required >
                               
                           </div><!-- form-group Finish -->
                            <div class="form-group"><!-- form-group Begin -->
                               
                               <label> Confirm Password</label>
                               
                               <input type="password" class="form-control" name="c_pass2" id="p2" required>
                               
                           </div><!-- form-group Finish -->
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label>Contact(format: xxxx-xxx-xxx):</label>
                               
                               <input type="text" class="form-control" name="c_contact"  pattern="^\d{4}-\d{3}-\d{3}$" required >
                               
                           </div><!-- form-group Finish -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label>City</label>
                               
                               <input type="text" class="form-control" name="c_city" required pattern="^[a-zA-Z]*$">
                               
                           </div><!-- form-group Finish -->
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label>Address</label>
                               
                               <input type="text" class="form-control" name="c_add" required pattern="^[a-zA-Z0-9_.-]*$">
                               
                           </div><!-- form-group Finish -->
                           <div class="text-center"><!-- text-center Begin -->
                               
                               <input  type="submit" name="register" class="btn btn-primary" value="Register" >
              
                               
                           </div><!-- text-center Finish -->
                           
                       </form><!-- form Finish -->
                       
                       
                   </div><!-- box-header Finish -->
                   
               </div><!-- box Finish -->
               
           </div><!-- col-md-9 Finish -->
           
       </div><!-- container Finish -->
   </div><!-- #content Finish --> 
 <script  type="text/javascript">
  $(document).ready(function() {
    $('#myform').bootstrapValidator({
        
       
        fields: {
            c_name: {
                validators: {
                        stringLength: {
                        min: 5,
                    },
                        notEmpty: {
                        message: 'Please supply your first name'
                    }
                }
            },
             
           
            c_contact: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your phone number'
                    },
                    c_contact: {
                        country: 'US',
                       
                        message: 'Please supply a vaild phone number'
                    }
                }
            },
            c_add: {
                validators: {
                     stringLength: {
                        min: 8,
                    },
                    notEmpty: {
                        message: 'Please supply your street address'
                    }
                }
            },
            c_city: {
                validators: {
                     stringLength: {
                        min: 4,
                    },
                    notEmpty: {
                        message: 'Please supply your city'
                    }
                }
            },
            
     
   email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
          
  c_pass1: {
            validators: {
                identical: {
                    field: 'c_pass2',
                    message: 'Confirm your password below - type same password please'
                }
            }
        },
        c_pass2: {
            validators: {
                identical: {
                    field: 'c_pass1',
                    message: 'The password and its confirm are not the same'
                }
            }
         },
      
            
            }
        })
    
  
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#myform').data('bootstrapValidator').resetForm();
 
            // Prevent form submission
            e.preventDefault();
 
            // Get the form instance
            var $form = $(e.target);
 
            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');
 
            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });
});
 
 </script>
<?php
addcustomer();
?>
    <?php
     include("includes/footer.php");
     ?>

</body>
</html>