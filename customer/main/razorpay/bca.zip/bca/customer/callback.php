<?php
include("includes/db.php");
require_once('config.php');
include('Razorpay.php');
session_start();
$arr=$_POST;

$py_id="ii";
foreach ($arr as $key => $value)
 {
 	$py_id=$value;
	
}

$order_id=$_SESSION['orderid'];
$get_orders = "select * from customer_orders where order_id='$order_id'";
            
            $run_orders = mysqli_query($con,$get_orders);
            $row_orders = mysqli_fetch_array($run_orders);
           $order_status = $row_orders['order_status'];
           $customer_id = $row_orders['customer_id'];
           $order_status='Complete';
$get_customer="Select * from customers where c_id='$customer_id'";
$run_customer = mysqli_query($con,$get_customer);
$row_customer= mysqli_fetch_array($run_customer);
$customer_email=$row_customer['customer_email'];
$customer_contact=$row_customer['customer_contact'];

$insert="Insert into pay(order_id,pay_id,customer_email,c_cont,date) values ('$order_id','$py_id','$customer_email','$customer_contact',NOW())";
$insert_payment = mysqli_query($con,$insert);
if($insert_payment)
{
	$rs='Complete';
	$update="Update customer_orders SET order_status='$rs' where order_id='$order_id'";
	$update_orders = mysqli_query($con,$update);

 if($update_orders)
 {
	echo"<script>alert('payment proceded');</script>";
	echo"<script>window.open('shipp.php','_self')</script>";
}
else
{
	die('here');
}
}
else{
	echo"<script>alert('payment  unsuccessfull');</script>";
	echo"<script>window.open('../index.php','_self')</script>";
}
?>