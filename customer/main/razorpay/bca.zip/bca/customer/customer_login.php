<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
    <script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>
<div class="box"><!-- box Begin -->
    
  <div class="box-header"><!-- box-header Begin -->
      
      <center><!-- center Begin -->
          
          <h1> Login </h1>
          
          
          <p class="lead"> Already have our account..? </p>
          
          
      </center><!-- center Finish -->
      
  </div><!-- box-header Finish -->
   
  <form id="sign-in-frm" method="post" action="checkout.php" ><!-- form Begin -->
      
      <div class="form-group"><!-- form-group Begin -->
         
          <label> Email </label>
          
                                
          <input name="c_email" type="text" class="form-control" id="c_email" required >
          
      </div><!-- form-group Finish -->
      
       <div class="form-group"><!-- form-group Begin -->
          
            
          <label> Password </label>
          
          <input name="c_pass" type="password" class="form-control" id="c_pass" required>
          
      </div><!-- form-group Finish -->
      
      <div class="text-center"><!-- text-center Begin -->
           <div class="form-group"><!-- form-group Begin -->
          <input type="submit"  name="login" value="Login" id="login" class="btn btn-primary">
              
          </div><!-- form-group Finish -->
      </div><!-- text-center Finish -->     
      
  </form><!-- form Finish -->
   
  <center><!-- center Begin -->
      
     <a href="customer_register.php">
         
         <h3> Dont have account..? Register here </h3>
         
     </a> 
      
  </center><!-- center Finish -->
    
</div><!-- box Finish -->
<script type="text/javascript">
$(document).ready(function() {
    $('#sign-in-frm').bootstrapValidator({
         fields: {    
  c_email: {
                validators: {
                    notEmpty: {
                        message: 'Please supply your email address'
                    },
                    emailAddress: {
                        message: 'Please supply a valid email address'
                    }
                }
            },
          
  c_pass: {
            validators: {
                notEmpty: {
                        message: 'Please supply your password'
                    }
            }
        },
        
      
            
            }
        })
    
  
        .on('success.form.bv', function(e) {
            $('#success_message').slideDown({ opacity: "show" }, "slow") // Do something ...
                $('#sign-in-frm').data('bootstrapValidator').resetForm();
 
            // Prevent form submission
            e.preventDefault();
 
            // Get the form instance
            var $form = $(e.target);
 
            // Get the BootstrapValidator instance
            var bv = $form.data('bootstrapValidator');
 
            // Use Ajax to submit form data
            $.post($form.attr('action'), $form.serialize(), function(result) {
                console.log(result);
            }, 'json');
        });

 });
 </script>

<?php 

if(isset($_POST['login'])){
    
    $customer_email = $_POST['c_email'];
    
    $customer_pass = $_POST['c_pass'];

    
    $select_customer = "select * from customers where customer_email='$customer_email' AND customer_pass='$customer_pass'";
    
    $run_customer = mysqli_query($con,$select_customer);
    
    
    $check_customer = mysqli_num_rows($run_customer);
    
    
    
    if($check_customer==0){
        
        echo "<script>alert('Your email or password is wrong')</script>";
        
        exit();
        
    }
    
    if($check_customer==1 AND empty($_SESSION['cart_item'])){
        
        $_SESSION['customer_email']=$customer_email;

        
       echo "<script>alert('You are Logged in')</script>"; 
        
       echo "<script>window.open('customer/my_account.php?my_orders','_self')</script>";
        
    }else{
        
        $_SESSION['customer_email']=$customer_email;
                 $customer_email=$_SESSION['customer_email'];

        $query="Select * from customers where customer_email='$customer_email'";
        $run_customer = mysqli_query($con,$query);
        $product=mysqli_fetch_array($run_customer);
        $c_id= $product['c_id'];
        $inser_customer=false;
         foreach ($_SESSION["cart_item"] as $item)
        {

          $pro_name=$item["name"];
         $p_id =$item['p_id'];
         $qty=$item["quantity"];
         $price=$item["price"];
         $subtotal=$item["subtotal"];
         $insert_customer="insert into cart(p_id,c_id,product_title,qty,price,subtotal) values('$p_id','$c_id','$pro_name','$qty','$price','$subtotal')";
         $insert_customer = mysqli_query($con,$insert_customer);


        }
          if($insert_customer)
          {
        
       echo "<script>alert('You are Logged in')</script>"; 
        
       echo "<script>window.open('checkout.php','_self')</script>";
     }
     else
     {

      die("loged in");
        }
     }
        
    }
    


?>