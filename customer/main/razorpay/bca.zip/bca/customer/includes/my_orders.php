<?php
require_once('config.php');
include('Razorpay.php');
use Razorpay\Api\Api;
$razor_pay_key_id = 'rzp_test_iSOhnBRYi97uzT';
    $secret_key = 'nXg10jFqWn2wEoCIB8zfwJB6';
$api = new Api($razor_pay_key_id, $secret_key);

?>
<center><!--  center Begin  -->
    
    <h1> My Orders </h1>
    
    <p class="lead"> Your orders on one place</p>
    
    
    
</center><!--  center Finish  -->


<hr>


<div class="table-responsive"><!--  table-responsive Begin  -->
    
    <table class="table table-bordered table-hover"><!--  table table-bordered table-hover Begin  -->
        
        <thead><!--  thead Begin  -->
            
            <tr><!--  tr Begin  -->
                
                <th> ON: </th>
                <th> Due Amount: </th>
                <th> Invoice No: </th>
                <th> Qty: </th>
                <th> Order Date:</th>
                <th> Paid / Unpaid: </th>
                <th colspan="2">Coupancode</th>
                <th> Status: </th>
                
            </tr><!--  tr Finish  -->
            
        </thead><!--  thead Finish  -->
        
        <tbody><!--  tbody Begin  -->
            
            <tr><!--  tr Begin  -->
              <?php 
            
            $customer_session = $_SESSION['customer_email'];
            
            $get_customer = "select * from customers where customer_email='$customer_session'";
            
            $run_customer = mysqli_query($con,$get_customer);
            
            $row_customer = mysqli_fetch_array($run_customer);
            
            $customer_id = $row_customer['c_id'];
            $customer_name=$row_customer['customer_name'];
            $customer_email=$row_customer['customer_email'];
            $customer_contact=$row_customer['customer_contact'];
            
            $get_orders = "select * from customer_orders where customer_id='$customer_id' AND order_status='pending'";
            
            $run_orders = mysqli_query($con,$get_orders);
            
            $i = 0;
            
            while($row_orders = mysqli_fetch_array($run_orders))
            {
                $pid =  $row_orders['product_id'];
                $order_id = $row_orders['order_id'];
                $due_amount = $row_orders['due_amount'];                
                $invoice_no = $row_orders['invoice_no'];                
                $qty = $row_orders['qty'];
                $order_date = substr($row_orders['order_date'],0,11);    
                $order_status = $row_orders['order_status'];
                $pri = $due_amount/$qty;
                $i++;
                
                if($order_status=='pending'){
                    
                    $order_status = 'Unpaid';
                    
                }else{
                    
                    $order_status = 'Paid';
                    
                }
            $query="Select product_price from product where product_id = '$pid'";
            $run_pro = mysqli_query($con,$query);
            $row_pro = mysqli_fetch_array($run_pro);
            $priy= $row_pro['product_price'];
            ?>
            
            <tr><!--  tr Begin  -->
                
                <th> <?php echo $i; ?> </th>
                <td><i class="fa fa-inr"></i><?php echo $due_amount; ?> </td>
                <td> <?php echo $invoice_no; ?> </td>
                <td> <?php echo $qty; ?> </td>
                
                <td> <?php echo $order_date; ?> </td>
                <td> <?php echo $order_status; ?> </td>
                <td colspan="2">
                    <?php 
                    if($order_status == 'Paid' )
                    {
                        echo "<strong> Payment completed</strong>";
                    }
                    else
                    {
                        if($priy==$pri)
                        {
                    ?>
                    <form method="POST" action="">
                    <input type="text" name="coupan" value="Enter code ">
                    <br>
                    <input type="submit" name="add" value="addcoupn" class="btn btn-primary">
                    </form>
                    <?php
                    if(isset($_POST['add']))
                    {
                        $code=$_POST['coupan'];
                        $cp="select * from coupons where coupon_code='$code'";
                        $run_cp = mysqli_query($con,$cp);
                        if( $run_cp)
                        {
                            $row_cp = mysqli_fetch_array($run_cp);
                            $pirce=$row_cp['coupon_price'];
                            $limit=$row_cp['coupon_limit'];
                            $used=$row_cp['coupon_used'];
                            if( $limit<=$used)
                            {
                                 echo"<script>alert('coupan limit extended');</script>";
    echo"<script>window.open('customer/my_account.php?my_orders','_self')</script>";
                            }
                            else{
                                $used=$used+1;
                                $due_amount=$qty* $pirce;
                                $update="update customer_orders SET due_amount='$due_amount' where customer_id='$customer_id'";
                               $run_updates = mysqli_query($con,$update); 
                               if($run_updates)
                               {
                                echo"<script>alert('coupan added extended');</script>";
    echo"<script>window.open('customer/my_account.php?my_orders','_self')</script>";
                                

                               }
                               else
                               {
                                die('here');
                               }
                               $update1="update coupons  SET coupon_used='$used' where coupon_code='$code'";
                               $run_updates1 = mysqli_query($con,$update1); 
                               
                            }
                        }
                         else{
                            echo"<script>alert('invalied Coupancode');</script>";
    echo"<script>window.open('customer/my_account.php?my_orders','_self')</script>";
                        }
                        }
                       
                    }
                    else
                    {
                     echo "<p>Coupancode used</p>";
                    }
                }
                    ?>
                </td>
                <td>
                    <?php
       if($order_status =='Unpaid'){
      $order  = $api->order->create([
  'receipt'         => '$order_id',
  'amount'          =>  $due_amount*100, // amount in the smallest currency unit
  'currency'        => 'INR',// <a href="https://razorpay.freshdesk.com/support/solutions/articles/11000065530-what-currencies-does-razorpay-support" target="_blank">See the list of supported currencies</a>.)
  'payment_capture' =>  '0'
]);
   
?>
       
        
        
        <form action="callback.php" method="POST"> 
            <script    src="https://checkout.razorpay.com/v1/checkout.js"    
            data-key="rzp_test_iSOhnBRYi97uzT" // Enter the Key ID generated from the Dashboard    data-amount="<?php echo $due_amount*100; ?>" // Amount is in currency subunits. Default currency is INR. Hence, 50000 means 50000 paise or INR 500.    data-currency="INR"
            data-order_id="<?php  $order_id ;?>"// Replace this with the order_id created using Orders API(https://razorpay.com/docs/api/orders).       
             data-buttontext="Pay Now"    
            data-name="ALSTORE"    
            data-description="A Wild Sheep Chase is the third novel by Japanese author Haruki Murakami"    
            data-image="images/AL_hex_store-1.png"    
            data-prefill.name="<?php echo $customer_name; ?>"    
            data-prefill.email="<?php echo $customer_email; ?>"    
            data-prefill.contact="<?php echo $customer_contact; ?>"    
            data-theme.color="#528FF0"></script>
            <input type="hidden" custom="Hidden Element" name="hidden">
        </form>
<?php
 $_SESSION['orderid']=$order_id;

        }
                    else{
                        ?>
                    <strong>Paid</strong>
                  <?php  } ?>
                </td>
                
            </tr><!--  tr Finish  -->
            
            <?php } ?>
            
            </tr><!--  tr Finish  -->
            
           <!--  tr Finish  -->
            
        </tbody><!--  tbody Finish  -->
        
    </table><!--  table table-bordered table-hover Finish  -->
    
</div><!--  table-responsive Finish  -->