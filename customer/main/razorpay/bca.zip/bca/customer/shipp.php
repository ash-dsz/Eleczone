<?php
include("header.php");


?>



<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>
    <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
<script src='http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js'></script>
<script src='http://cdnjs.cloudflare.com/ajax/libs/bootstrap-validator/0.4.5/js/bootstrapvalidator.min.js'></script>

   <div id="content"><!-- #content Begin -->
       <div class="container"><!-- container Begin -->
          
          
           
           <div class="col-md-9"><!-- col-md-9 Begin -->
               
               <div class="box"><!-- box Begin -->
                   
                   <div class="box-header"><!-- box-header Begin -->
                       
                       <center><!-- center Begin -->
                           
                           <h2>Add Shipping Address</h2>
                           
                       </center><!-- center Finish -->
                      
                       <form action="add_ship.php" method="post" enctype="multipart/form-data" id="form1" ><!-- form Begin -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label> Name</label>
                               
                               <input type="text" class="form-control" name="c_name" required pattern="^[a-zA-Z]*$">
                               
                           </div><!-- form-group Finish -->
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label> Email (xxxx@xxxx.xxxx)</label>
                               
                               <input type="text" class="form-control" name="email" required pattern="^[a-zA-Z0-9._]+@[a-zA-Z0-9._]+\.[a-zA-Z]{2,4}$">
                               
                           </div><!-- form-group Finish -->
                           
                          
                            <div class="form-group"><!-- form-group Begin -->
                               <label>Contact(format: xxxx-xxx-xxx):</label>
                               
                               <input type="text" class="form-control" name="c_contact"  pattern="^\d{4}-\d{3}-\d{3}$" required >
                               
                           </div><!-- form-group Finish -->
                           
                           
                           <div class="form-group"><!-- form-group Begin -->
                               
                               <label>Flat/house no-Flat/House name</label>
                               
                               <input type="text" class="form-control" name="c_add" required pattern="^[a-zA-Z0-9_.-]*$">
                                </div><!-- form-group Finish -->
                                 <div class="form-group"><!-- form-group Begin -->
                               <label>street</label>
                               
                               <input type="text" class="form-control" name="c_street" required pattern="^[a-zA-Z]*$">
                               
                           </div><!-- form-group Finish -->
                            <div class="form-group"><!-- form-group Begin -->
                               <label>City</label>
                               
                               <input type="text" class="form-control" name="c_city" required pattern="^[a-zA-Z]*$">
                               
                           </div><!-- form-group Finish -->
                           <div class="form-group"><!-- form-group Begin -->
                               <label>Pincode:</label>
                               
                               <input type="text" class="form-control" name="c_pin"  pattern="^\d{6}$" required >
                               
                           </div><!-- form-group Finish -->

                              <label>State</label>
                               
                               <input type="text" class="form-control" name="c_state" required pattern="^[a-zA-Z]*$">
                               
                           </div><!-- form-group Finish --> 
                          
                           <div class="text-center"><!-- text-center Begin -->
                               
                               <input  type="submit" name="register" class="btn btn-primary" value="Register" >
              
                               
                           </div><!-- text-center Finish -->
                           
                       </form><!-- form Finish -->
                       
                       
                   </div><!-- box-header Finish -->
                   
               </div><!-- box Finish -->
               
           </div><!-- col-md-9 Finish -->
           
       </div><!-- container Finish -->
   </div><!-- #content Finish --> 
 
  
 
</body>
</html>
