<?php
include("includes/db.php");
session_start();
if(isset($_POST['register']))
 {
  $order_id=$_SESSION['orderid'];
  $name=$_POST['c_name'];
  $email=$_POST['email'];
  $c_contact=$_POST['c_contact'];
  $c_add=$_POST['c_add'];
  $c_pin=$_POST['c_pin'];
  $c_city=$_POST['c_city'];
  $c_state=$_POST['c_state'];
  $c_street=$_POST['c_street'];
$insert="insert into shipping (order_id,name,email,contact,addr,pin,city,state,street) VALUES ('$order_id',' $name','$email','$c_contact','$c_add','$c_pin','$c_city','$c_state',' $c_street')";
 $run_shipp = mysqli_query($con,$insert);
 if ($run_shipp) {
      echo"<script>alert('order proceded');</script>";
  echo"<script>window.open('../index.php','_self')</script>";
    unset($_SESSION['orderid']);
 }
 else
 {
  die('error');
}
 }
?>