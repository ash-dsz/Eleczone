<?php
    
    $razor_pay_key_id = 'rzp_test_iSOhnBRYi97uzT
';
    $secret_key = 'nXg10jFqWn2wEoCIB8zfwJB6
';
    define("KEY",$razor_pay_key_id);
    define("API_SECRET",$secret_key);
?>