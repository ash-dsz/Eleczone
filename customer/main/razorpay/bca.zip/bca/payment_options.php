<div class="box"><!-- box Begin -->
    <?php 
    
    $customer_email = $_SESSION['customer_email'];
    
    $select_customer = "select * from customers where customer_email='$customer_email'";
    
    $run_customer = mysqli_query($con,$select_customer);
    
    $row_customer = mysqli_fetch_array($run_customer);
    
    
    $customer_id = $row_customer['c_id'];
    
    ?>
    <h1 class="text-center">Payment Options For You</h1>  
    
     <p class="lead text-center"><!-- lead text-center Begin -->
       <div class='col-md-4 col-sm-6 single' >   
<a href="order.php?c_id=<?php echo $customer_id ?>"> <img src="includes/Razorpay.png" alt="img not found">pay using Razor pay </a>
         </div>
     </p><!-- lead text-center Finish -->
     
    
</div><!-- box Finish -->