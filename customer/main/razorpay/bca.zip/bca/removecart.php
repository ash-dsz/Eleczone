<?php
session_start();

                  if(isset($_GET['action']))
                  {
                  
                     if(!empty($_SESSION["cart_item"]))
                  {
                      if(count($_SESSION["cart_item"])==1)
                      {
                         session_destroy();
                         echo "<script>alert('product deleted')</script>";
                         echo "<script>window.open('cart.php','_self')</script>";
                      }
                  else{
                        foreach($_SESSION["cart_item"] as $k => $v) {
                              if($_GET["p_id"] == $k)
                        unset($_SESSION["cart_item"][$k]);
                          if(empty($_SESSION["cart_item"]))
                                unset($_SESSION["cart_item"]);
                               echo "<script>alert('product deleted')</script>";
                               echo "<script>window.open('cart.php','_self')</script>";
                      }
                  }
                }
                echo "<script>alert('product deleted')</script>";
                         echo "<script>window.open('cart.php','_self')</script>";
}

               ?>
               