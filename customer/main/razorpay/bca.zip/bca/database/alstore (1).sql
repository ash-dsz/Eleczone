-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 12, 2021 at 01:37 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `alstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `a_id` int(20) NOT NULL,
  `a_name` text NOT NULL,
  `admin_email` text NOT NULL,
  `admin_pass` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`a_id`, `a_name`, `admin_email`, `admin_pass`) VALUES
(1, 'Shravan', 'admin@gmail.com', '1234'),
(2, 'Sam', 'sam123@gmail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(10) NOT NULL,
  `p_id` int(10) NOT NULL,
  `c_id` int(10) NOT NULL,
  `product_title` text NOT NULL,
  `qty` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `subtotal` int(15) NOT NULL,
  `c_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`cart_id`, `p_id`, `c_id`, `product_title`, `qty`, `price`, `subtotal`, `c_date`) VALUES
(28, 27, 14, 'Aloe vera gel', 3, 224, 672, '0000-00-00'),
(29, 28, 14, 'Rose water', 1, 269, 269, '0000-00-00'),
(30, 24, 14, 'Charcol soap', 1, 199, 199, '0000-00-00'),
(31, 21, 13, 'Skin cream', 1, 449, 449, '0000-00-00'),
(32, 24, 13, 'Charcol soap', 1, 199, 199, '0000-00-00'),
(33, 28, 13, 'Rose water', 1, 269, 269, '0000-00-00'),
(34, 28, 14, 'Rose water', 1, 269, 269, '0000-00-00'),
(35, 24, 14, 'Charcol soap', 1, 199, 199, '0000-00-00'),
(36, 25, 14, 'Hair oil', 1, 314, 314, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `coupan_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `coupon_title` text NOT NULL,
  `coupon_price` int(10) NOT NULL,
  `coupon_code` text NOT NULL,
  `coupon_limit` int(10) NOT NULL,
  `coupon_used` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`coupan_id`, `product_id`, `coupon_title`, `coupon_price`, `coupon_code`, `coupon_limit`, `coupon_used`) VALUES
(1, 24, 'Charcol soap', 189, 'cha240', 4, 4),
(2, 21, 'Skin cream', 399, 'skin399', 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `c_id` int(10) NOT NULL,
  `customer_name` text NOT NULL,
  `customer_email` text NOT NULL,
  `customer_pass` text NOT NULL,
  `customer_city` text NOT NULL,
  `customer_contact` text NOT NULL,
  `customer_address` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`c_id`, `customer_name`, `customer_email`, `customer_pass`, `customer_city`, `customer_contact`, `customer_address`) VALUES
(13, 'Shravan', 'shravanbangera14@gmail.com', '1234', 'kudla', '9876-543-2190', 'mangalore-karnataka'),
(14, 'Sharath', 'shravanbangera15@gmail.com', 'Sannu46#', 'Mangalore', '9148-731-040', '11-140-karmicacolany');

-- --------------------------------------------------------

--
-- Table structure for table `customer_orders`
--

CREATE TABLE `customer_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `due_amount` int(10) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `qty` int(10) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` text NOT NULL,
  `product_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_orders`
--

INSERT INTO `customer_orders` (`order_id`, `customer_id`, `due_amount`, `invoice_no`, `qty`, `order_date`, `order_status`, `product_id`) VALUES
(25, 13, 189, 300151053, 1, '2020-04-25', 'Complete', 28),
(26, 14, 189, 1534114923, 3, '2020-05-20', 'Complete', 27),
(28, 14, 189, 234665183, 1, '2020-05-26', 'Complete', 24),
(29, 14, 189, 1485166557, 1, '2020-05-26', 'Complete', 21),
(30, 14, 189, 698155364, 1, '2020-05-26', 'pending', 24),
(31, 14, 189, 43267381, 1, '2020-06-02', 'Complete', 25),
(34, 13, 189, 1578913900, 1, '2020-06-27', 'pending', 24),
(35, 13, 269, 699528711, 1, '2020-06-28', 'Complete', 28),
(36, 14, 189, 1916170560, 1, '2020-06-29', 'pending', 28),
(37, 14, 189, 1916170560, 1, '2020-06-29', 'pending', 24),
(38, 14, 189, 1916170560, 1, '2020-06-29', 'Complete', 25);

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `order_id` int(10) NOT NULL,
  `pay_id` text NOT NULL,
  `customer_email` text NOT NULL,
  `c_cont` text NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`order_id`, `pay_id`, `customer_email`, `c_cont`, `date`) VALUES
(25, 'pay_Eiyk9wpe0K3grU', 'shravanbangera14@gmail.com', '9876-543-2190', '2020-04-26'),
(26, 'pay_EsU3UvrVIH8cgH', 'shravanbangera15@gmail.com', '9148-731-040', '2020-05-20'),
(28, 'pay_EupzBYgTZnmxWy', 'shravanbangera15@gmail.com', '9148-731-040', '2020-05-26'),
(29, 'pay_Euq9HxUQ9minrb', 'shravanbangera15@gmail.com', '9148-731-040', '2020-05-26'),
(31, 'pay_ExdlMYjGLCdams', 'shravanbangera15@gmail.com', '9148-731-040', '2020-06-02'),
(35, 'pay_F825NC5wLlURey', 'shravanbangera14@gmail.com', '9876-543-2190', '2020-06-28'),
(38, 'pay_F8MQ0cNaoXpVWN', 'shravanbangera15@gmail.com', '9148-731-040', '2020-06-29');

-- --------------------------------------------------------

--
-- Table structure for table `pending_orders`
--

CREATE TABLE `pending_orders` (
  `order_id` int(10) NOT NULL,
  `customer_id` int(10) NOT NULL,
  `invoice_no` int(100) NOT NULL,
  `product_id` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pending_orders`
--

INSERT INTO `pending_orders` (`order_id`, `customer_id`, `invoice_no`, `product_id`, `qty`, `order_status`) VALUES
(25, 13, 300151053, 28, 1, 'Complete'),
(26, 14, 1534114923, 27, 3, 'Complete'),
(28, 14, 234665183, 24, 1, 'Complete'),
(29, 14, 1485166557, 21, 1, 'Complete'),
(30, 14, 698155364, 24, 1, 'Complete'),
(31, 14, 43267381, 25, 1, 'Complete'),
(34, 13, 1578913900, 24, 1, 'pending'),
(35, 13, 699528711, 28, 1, 'pending'),
(36, 14, 1916170560, 28, 1, 'pending'),
(37, 14, 1916170560, 24, 1, 'pending'),
(38, 14, 1916170560, 25, 1, 'Complete');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `product_id` int(10) NOT NULL,
  `p_cat_id` int(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `product_title` text NOT NULL,
  `product_img1` text NOT NULL,
  `product_img2` text NOT NULL,
  `product_price` int(10) NOT NULL,
  `product_desc` text NOT NULL,
  `product_keywords` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `p_cat_id`, `date`, `product_title`, `product_img1`, `product_img2`, `product_price`, `product_desc`, `product_keywords`) VALUES
(20, 1, '2020-03-07 15:23:34', 'Shampoos', 'hairwash.jpg', 'hairwash2.jpg', 449, '<p>A blend of herbs and oils</p>\r\n<p>Free from harmful ingredients</p>', 'Shampoos'),
(21, 2, '2020-03-07 15:24:48', 'Skin cream', 'skincream.jpg', 'skincream2.jpg', 449, '<p>Repairs damaged skin</p>\r\n<p>Prevents early cell aging</p>\r\n<p>No paraben</p>', 'Skin Creams'),
(22, 2, '2020-02-20 05:55:59', 'Face cream', 'facecream.jpg', 'facecream2.jpg', 449, '<p>Fights dry skin</p>\r\n<p>Daily sun protection</p>\r\n<p>No paraben</p>', 'Face cream'),
(23, 3, '2020-02-18 09:28:34', 'Goat milk soap', 'goatsoap.jpg', 'goatsop2.jpg', 199, '<p>Premium Quality</p>\r\n<p>Rich in charcol</p>\r\n<p>Gently removes dead skin</p>', 'Soap'),
(24, 3, '2020-02-18 09:29:44', 'Charcol soap', 'charsoap.jpg', 'charcolsoap2.jpg', 199, '<p>Premium Quality</p>\r\n<p>Rich in charcol</p>\r\n<p>Controls oil</p>', 'Soap'),
(25, 4, '2020-02-18 09:30:45', 'Hair oil', 'hairoil.jpg', 'hairoil.jpg', 314, '<p>100% pure</p>\r\n<p>Free from chemicals</p>', 'Oils'),
(26, 4, '2020-02-18 09:32:07', 'Coconut virgin oil', 'coconutoil.jpg', 'coconutoil.jpg', 269, '<p>100% pure virgin coconut oil</p>\r\n<p>Packed with many health benefits</p>', 'Oils'),
(27, 5, '2020-02-18 09:33:55', 'Aloe vera gel', 'aloegel.jpg', 'aloegel.jpg', 224, '<p>99% Pure aloe vera gel</p>\r\n<p>Contains 100% bio activs</p>\r\n<p>Free from harmful ingredients</p>', 'Gel'),
(28, 5, '2020-02-18 09:35:48', 'Rose water', 'rosewater.jpg', 'rosewater.jpg', 269, '<p>100% pure from chemicals</p>\r\n<p>Contains health benefits</p>', 'Oils'),
(29, 6, '2020-02-18 09:37:28', 'Combo-Hair oil,rose water,gel', 'combo2.jpg', 'combo2.jpg', 807, '<p>Combat dry skin and hair related problems</p>', 'Combo'),
(30, 6, '2020-02-18 09:38:26', 'Combo-Coconut oil,rose water,gel', 'combo1.jpg', 'combo1.jpg', 762, '<p>Combat dry skin and hair related problems</p>', 'Combo');

-- --------------------------------------------------------

--
-- Table structure for table `product_categories`
--

CREATE TABLE `product_categories` (
  `p_cat_id` int(10) NOT NULL,
  `p_cat_title` text NOT NULL,
  `p_cat_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product_categories`
--

INSERT INTO `product_categories` (`p_cat_id`, `p_cat_title`, `p_cat_desc`) VALUES
(1, 'SHAMPOOS', 'SHAMPOO'),
(2, 'CREAMS', 'CREAM'),
(3, 'SOAPS', 'SOAP'),
(4, 'OILS', 'OIL'),
(5, 'ESSENTIALS', 'ESSENTIAL'),
(6, 'COMBO', 'COMBO'),
(7, 'juice', 'herbel juie');

-- --------------------------------------------------------

--
-- Table structure for table `shipping`
--

CREATE TABLE `shipping` (
  `order_id` int(25) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `contact` text NOT NULL,
  `addr` text NOT NULL,
  `pin` text NOT NULL,
  `city` text NOT NULL,
  `state` text NOT NULL,
  `street` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `shipping`
--

INSERT INTO `shipping` (`order_id`, `name`, `email`, `contact`, `addr`, `pin`, `city`, `state`, `street`) VALUES
(25, ' Shravan', 'shravanbangera14@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ''),
(26, ' Sharath', 'shravanbangera15@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ''),
(28, ' Sharath', 'shravanbangera15@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ''),
(29, ' Sharath', 'shravanbangera15@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ''),
(31, ' Sharath', 'shravanbangera15@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ' karmicacolany'),
(35, ' Shravan', 'shravanbangera14@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ' karmicacolany'),
(38, ' Shravan', 'shravanbangera14@gmail.com', '9148-731-040', '11-140', '575016', 'Mangalore', 'Karnataka', ' karmicacolany');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`a_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`),
  ADD KEY `p_id` (`p_id`),
  ADD KEY `c_id` (`c_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`coupan_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_id`),
  ADD KEY `p_cat_id` (`p_cat_id`);

--
-- Indexes for table `product_categories`
--
ALTER TABLE `product_categories`
  ADD PRIMARY KEY (`p_cat_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `a_id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `coupan_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `c_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `customer_orders`
--
ALTER TABLE `customer_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `pending_orders`
--
ALTER TABLE `pending_orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `product_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `product_categories`
--
ALTER TABLE `product_categories`
  MODIFY `p_cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer_orders`
--
ALTER TABLE `customer_orders`
  ADD CONSTRAINT `customer_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`c_id`);

--
-- Constraints for table `pending_orders`
--
ALTER TABLE `pending_orders`
  ADD CONSTRAINT `pending_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`c_id`),
  ADD CONSTRAINT `pending_orders_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`p_cat_id`) REFERENCES `product_categories` (`p_cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
