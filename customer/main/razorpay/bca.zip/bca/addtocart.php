<?php 

    $active='Cart';
    include("includes/header.php");
    
?>
   
             
         


                        

                           


                            <form action="addtocart.php" class="form-horizontal" method="get"><!-- form-horizontal Begin -->
                               <div class="form-group"><!-- form-group Begin -->
                                   <label for="" class="col-md-5 control-label">Products Quantity</label>
                                   <div class="col-md-7"><!-- col-md-7 Begin -->
                                          <select name="product_qty"  class="form-control"><!-- select Begin -->
                                           <option>1</option>
                                           <option>2</option>
                                           <option>3</option>
                                           <option>4</option>
                                           <option>5</option>
                                           </select><!-- select Finish -->
                                   
                                    </div><!-- col-md-7 Finish -->
                                   
                               </div><!-- form-group Finish -->
                               
                               <input type="hidden" name="pro_id" value="<?php echo $product_id; ?>">
                               
                               <p class="price" name="price"><i class="fa fa-inr"></i> <?php echo $pro_price; ?></p>
                               
                               <p class="text-center buttons">
                                <input type="submit" name="addtocart" class="btn btn-primary i fa fa-shopping-cart" value="addtocart">

                                </p>
                              
                           </form><!-- form-horizontal Finish -->
                           <?php 

if(!empty($_GET["addtocart"])) {
$pid=$_GET['pro_id'];
$query="SELECT * FROM product WHERE product_id=$pid";
$result=mysqli_query($con,$query);
while($productByCode=mysqli_fetch_array($result)){
$itemArray = array($productByCode['product_id']=>array('p_id'=>$productByCode['product_id'], 'name'=>$productByCode['product_title'],  'quantity'=>$_GET['product_qty'], 'price'=>$productByCode['product_price'],'subtotal'=>$_GET['product_qty']*$productByCode['product_price']));
if(!empty($_SESSION["cart_item"])) {
// searches for specific value code

 
//The array_merge() function merges one or more arrays into one array.
    $_SESSION["cart_item"] = array_merge($_SESSION["cart_item"],$itemArray);
}
 else {
        $_SESSION["cart_item"] = $itemArray;
      }
  }
}
?>

  
<script src="js/jquery-331.min.js"></script>
    <script src="js/bootstrap-337.min.js"></script>