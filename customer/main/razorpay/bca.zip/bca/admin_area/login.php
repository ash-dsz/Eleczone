<?php 

    session_start();
    include("includes/db.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>ALStoreAdmin Area</title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css">
    <script type="text/javascript">
    function check()
    {
      if(document.login_form.admin_pass.value=="")
  {
    alert("Plese Enter Your Password");
  document.login_form.admin_pass.focus();
  return false;
  } 
  if(document.login_form.admin_email.value=="")
  {
    alert("Plese Enter your Email Address");
  document.login_form.admin_email.focus();
  return false;
  }
  e=document.login_form.admin_email.value;
    f1=e.indexOf('@');
    f2=e.indexOf('@',f1+1);
    e1=e.indexOf('.');
    e2=e.indexOf('.',e1+1);
    n=e.length;

    if(!(f1>0 && f2==-1 && e1>0 && e2==-1 && f1!=e1+1 && e1!=f1+1 && f1!=n-1 && e1!=n-1))
    {
      alert("Please Enter valid Email");
      document.login_form.admin_email.focus();
      return false;
    }
  return true;
    }
 </script>
</head>
<body>
  
   <div class="container"><!-- container begin -->
   
       <form action="login.php" class="form-login" method="post" name="login_form" onsubmit="check()"><!-- form-login begin -->
           <h2 class="form-login-heading"> Admin Login </h2>
           
           <input type="text" class="form-control" placeholder="Email Address" name="admin_email" id="admin_email" required>
           <input type="password" class="form-control" placeholder="Your Password" name="admin_pass" id="admin_pass" required>
           <div class="text-center">
           <input type="submit"  name="admin_login" value="Login" id="login" class="btn btn-primary"><!-- btn btn-lg btn-primary btn-block finish -->
           </div>
       </form><!-- form-login finish -->
   </div><!-- container finish -->
     
</body>
</html>


<?php 

    if(isset($_POST['admin_login'])){
        
        $admin_email = mysqli_real_escape_string($con,$_POST['admin_email']);
        
        $admin_pass = mysqli_real_escape_string($con,$_POST['admin_pass']);
        
        $get_admin = "select * from admins where admin_email='$admin_email' AND admin_pass='$admin_pass'";
        
        $run_admin = mysqli_query($con,$get_admin);
        
        $count = mysqli_num_rows($run_admin);
        
        if($count==1){
            
            $_SESSION['admin_email']=$admin_email;
            
            echo "<script>alert('Logged in. Welcome Back')</script>";
            
            echo "<script>window.open('index.php?dashboard','_self')</script>";
            
        }else{
            
            echo "<script>alert('Email or Password is Wrong !')</script>";
            
        }
        
    }

?>