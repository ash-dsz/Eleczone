<?php
error_reporting(0);
session_start();
    include("includes/db.php");
if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('login.php','_self')</script>";
        
    }else{
if(isset($_GET['id']))
{
	$cid=$_GET['id'];
	$query="Select * from customers where c_id='$cid'";
	$run_c = mysqli_query($con,$query);
	$row_c=mysqli_fetch_array($run_c);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title> Sendmail </title>
    <link rel="stylesheet" href="css/bootstrap-337.min.css">
    <link rel="stylesheet" href="font-awsome/css/font-awesome.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div class="row"><!-- row Begin -->
    
    <div class="col-lg-12"><!-- col-lg-12 Begin -->
        
        <ol class="breadcrumb"><!-- breadcrumb Begin -->
            
            <li class="active"><!-- active Begin -->
                
                <i class="fa fa-dashboard"></i> Dashboard / sendcoupan
                
            </li><!-- active Finish -->
            
        </ol><!-- breadcrumb Finish -->
        
    </div><!-- col-lg-12 Finish -->
    
</div><!-- row Finish -->
       
<div class="row"><!-- row Begin -->
    
    <div class="col-lg-12"><!-- col-lg-12 Begin -->
        
        <div class="panel panel-default"><!-- panel panel-default Begin -->
            
           <div class="panel-heading"><!-- panel-heading Begin -->
               
               <h3 class="panel-title"><!-- panel-title Begin -->
                   
                   <i class="fa fa-money fa-fw"></i> Send coupan 
                   
               </h3><!-- panel-title Finish -->
               
           </div> <!-- panel-heading Finish -->
           
           <div class="panel-body"><!-- panel-body Begin -->
               
               <form method="POST" class="form-horizontal" enctype="multipart/form-data"><!-- form-horizontal Begin -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Customer name</label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="customer_name" type="text" class="form-control"  value=<?php  echo $row_c['customer_name'];?>>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Code  </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <select name="coupon_code" class="form-control"><!-- form-control Begin -->
                              
                              <option> Select a Code </option>
                              
                              <?php 
                              
                              $get = "SELECT * FROM coupons";
                              $run = mysqli_query($con,$get);
                              
                              while ($row=mysqli_fetch_array($run))
                              {
                                  
                                  $coupon_code = $row['coupon_code'];
                                  $coupon_title = $row['coupon_title'];
                                  
                                  echo "
  
                                  <option value='$coupon_code'> $coupon_title </option>
                                  
                                  ";
                                  
                              }
                              
                              ?>
                              
                          </select><!-- form-control Finish -->
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"> Customer email </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="customer_email" type="text" class="form-control" value=<?php echo $row_c['customer_email'] ?>>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                       <div class="form-group"><!-- form-group Begin -->
                      <label class="col-md-3 control-label"> customer contact </label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="product_price" type="text" class="form-control" value=<?php echo $row_c['customer_contact'] ?>>
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
                   <div class="form-group"><!-- form-group Begin -->
                       
                      <label class="col-md-3 control-label"></label> 
                      
                      <div class="col-md-6"><!-- col-md-6 Begin -->
                          
                          <input name="submit" value="sendmail" type="submit" class="btn btn-primary form-control fa fa-paper-plane">
                          
                      </div><!-- col-md-6 Finish -->
                       
                   </div><!-- form-group Finish -->
                   
               </form><!-- form-horizontal Finish -->
               
           </div><!-- panel-body Finish -->
            
        </div><!-- canel panel-default Finish -->
        
    </div><!-- col-lg-12 Finish -->
    
</div><!-- row Finish -->
   
<?php
if(isset($_POST['submit']))
{
	$email = $_POST['customer_email'];
	$code = $_POST['coupon_code'];
	$get_p_cats = "SELECT * FROM coupons WHERE coupon_code= '$code'";
    $run_p_cats = mysqli_query($con,$get_p_cats);
    $row_p_cats=mysqli_fetch_array($run_p_cats);
    $coupon_title = $row_p_cats['coupon_title'];
    
	$subject = "use this coupan to get instent off on $coupon_title ";
    $msg = "your code   <b> $code</b> 
    note:offer is only for limited customer grab it now
     --advait lifestyle"
    ;

	
	function smtp_mailer($to,$subject, $msg){
	require_once("smtp/class.phpmailer.php");
	$mail = new PHPMailer(); 
	$mail->IsSMTP(); 
	$mail->SMTPDebug = 1; 
	$mail->SMTPAuth = true; 
	$mail->SMTPSecure = 'TLS'; 
	$mail->Host = "smtp.sendgrid.net";
	$mail->Port = 587; 
	$mail->IsHTML(true);
	$mail->CharSet = 'UTF-8';
	$mail->Username = "shettyappu243";
	$mail->Password = "appuappu243";
	$mail->SetFrom("thilakrajshetty243@gmail.com");
	$mail->Subject = $subject;
	$mail->Body =$msg;
	$mail->AddAddress($to);
	if(!$mail->Send()){
		return 0;
	}else{
		  echo "<script>alert('Mail sent success fully ')</script>";
            
            echo "<script>window.open('index.php?view_coupans','_self')</script>";

	}
}
}
echo smtp_mailer($email,$subject,$msg);
}
}
?>
</body>
</html>