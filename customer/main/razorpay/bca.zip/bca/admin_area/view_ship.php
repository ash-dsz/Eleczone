<?php 
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('login.php','_self')</script>";
        
    }else{

?>
<?php
 if(isset($_GET['view_ship']))
 {
 $id=$_GET['view_ship'];
 $query="SELECT * FROM shipping WHERE order_id = '$id'";
 $run = mysqli_query($con,$query);
 $row_order=mysqli_fetch_array($run);
 $name=$row_order['name'];
 $email=$row_order['email'];
 $contact=$row_order['contact'];
 $addr=$row_order['addr'];
 $pin=$row_order['pin'];
 $city=$row_order['city'];
 $state=$row_order['state'];
 $street=$row_order['street'];
?>
<div class="row"><!-- row 1 begin -->
    <div class="col-lg-12"><!-- col-lg-12 begin -->
        <ol class="breadcrumb"><!-- breadcrumb begin -->
            <li class="active"><!-- active begin -->
                
                <i class="fa fa-dashboard"></i> Dashboard / View address
                
            </li><!-- active finish -->
        </ol><!-- breadcrumb finish -->
    </div><!-- col-lg-12 finish -->
</div><!-- row 1 finish -->
<div class="row"><!-- row 2 begin -->
    <div class="col-lg-12"><!-- col-lg-12 begin -->
        <div class="panel panel-default"><!-- panel panel-default begin -->
            <div class="panel-heading"><!-- panel-heading begin -->
               <h3 class="panel-title"><!-- panel-title begin -->
               
                   <i class="fa fa-tags"></i>  View address
                
               </h3><!-- panel-title finish --> 
            </div><!-- panel-heading finish -->
            
           <div class="panel-body"><!-- panel-body begin -->
                <div class="table-responsive"><!-- table-responsive begin -->
                    <table class="table table-striped table-bordered table-hover"><!-- table table-striped table-bordered table-hover begin -->
                    	<tr>
                    		<td>Name</td>
                    		<td><?php echo $name; ?></td>
                    	</tr>
                    	<tr>
                    		<td>Email</td>
                    		<td><?php echo $email; ?></td>
                    	</tr>
                    	<tr>
                    		<td>Contact</td>
                    		<td><?php echo $contact; ?></td>
                    	</tr>
                    	<tr>
                    		<td>DrNo/flat no</td>
                    		<td><?php echo $addr; ?></td>
                    	</tr>
                    	<tr>
                    		<td>street</td>
                    		<td><?php echo $street; ?></td>
                    	</tr>
                    	<tr>
                    		<td>City</td>
                    		<td><?php echo $city; ?></td>
                    	</tr>
                    	<tr>
                    		<td>Pin code</td>
                    		<td><?php echo  $pin; ?></td>
                    	</tr>
                    	<tr>
                    		<td>State</td>
                    		<td><?php echo $state; ?></td>
                    	</tr>

							<tr>
								<td>
									<a href="index.php?view_orders"><!-- a href begin -->
                    <i class="btn btn-primary">Back</i> 
                </a><!-- a href finish -->
								</td>
							</tr>
                        </table><!-- table table-striped table-bordered table-hover end -->
                    </div><!-- table-responsive end -->
                </div><!-- panel-body end -->

        </div><!-- panel panel-default finish -->
    </div><!-- col-lg-12 finish -->
</div><!-- row 2 finish -->
                <?php
            }
        }
                ?>