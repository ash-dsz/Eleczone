<?php 

$con = mysqli_connect("localhost","root","byadagodu","alstore");
if ($con->connect_error) {
    die ("Database connection error".$con->connect_error);
    exit();
}
?>