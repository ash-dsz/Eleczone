<?php 
    
    if(!isset($_SESSION['admin_email'])){
        
        echo "<script>window.open('login.php','_self')</script>";
       
        
    }else{

?>
<div class="row"><!-- row 1 begin -->
    <div class="col-lg-12"><!-- col-lg-12 begin -->
        <ol class="breadcrumb"><!-- breadcrumb begin -->
            <li class="active"><!-- active begin -->
                
                <i class="fa fa-dashboard"></i> Dashboard / View Payments
                
            </li><!-- active finish -->
        </ol><!-- breadcrumb finish -->
    </div><!-- col-lg-12 finish -->
</div><!-- row 1 finish -->
<div class="row"><!-- row 2 begin -->
    <div class="col-lg-12"><!-- col-lg-12 begin -->
        <div class="panel panel-default"><!-- panel panel-default begin -->
            <div class="panel-heading"><!-- panel-heading begin -->
               <h3 class="panel-title"><!-- panel-title begin -->
               
                   <i class="fa fa-tags"></i>  View Customers
                
               </h3><!-- panel-title finish --> 
            </div><!-- panel-heading finish -->
            <div class="panel-body"><!-- panel-body begin -->
                <div class="table-responsive"><!-- table-responsive begin -->
                    <table class="table table-striped table-bordered table-hover"><!-- table table-striped table-bordered table-hover begin -->
                        
                        <thead><!-- thead begin -->
                            <tr><!-- tr begin -->
                                <th> No: </th>
                                <th> Name: </th>
                                <th> Product titel </th>
                                <th> E-Mail: </th>
                                <th> payment_id: </th>
                                <th> Contact: </th>
                                <th> payment_date: </th>
                            </tr><!-- tr finish -->
                        </thead><!-- thead finish -->
                        
                        <tbody><!-- tbody begin -->
                        	<tr>
                        	<?php
                        	$i=1;
                        	$get_p="Select * from pay";
                        	$run_p= mysqli_query($con,$get_p);
                        	while($row_p=mysqli_fetch_array($run_p)){
                        		$o_id= $row_p['order_id'];
                        		$pa_id= $row_p['pay_id'];
                        		$email= $row_p['customer_email'];
                        		$Contact = $row_p['c_cont'];
                        		$payment_date= $row_p['date'];

                        		$get_o="Select * from customer_orders where order_id= '$o_id' AND order_status='Complete'";
                        		$run_o= mysqli_query($con,$get_o);
                        		$row_o=mysqli_fetch_array($run_o);
                        		$c_id= $row_o['customer_id'];
                        		$p_id= $row_o['product_id'];

                        		$get_c = "select customer_name from customers where c_id='$c_id'";
                                $run_c = mysqli_query($con,$get_c);
                                $row_c=mysqli_fetch_array($run_c);
                                $c_name = $row_c['customer_name'];

                                $get_pro = "select product_title from product where product_id='$p_id'";
                                
                                $run_pro = mysqli_query($con,$get_pro);
                                $row_pro=mysqli_fetch_array($run_pro);
                                $pro_title = $row_pro['product_title'];
                                ?>

                                <td> <?php echo $i; ?> </td>
                                <td> <?php echo $c_name; ?> </td>
                                <td> <?php echo $pro_title; ?> </td>
                                <td> <?php echo $email; ?> </td>
                                <td> <?php echo $pa_id ?> </td>
                                <td> <?php echo $Contact ?> </td>
                                 <td> <?php echo $payment_date ?> </td>
                             </tr>
                                <?php
                        	}

                        	?>
                        	 </tbody><!-- tbody finish -->
                        
                    </table><!-- table table-striped table-bordered table-hover finish -->
                </div><!-- table-responsive finish -->
            </div><!-- panel-body finish -->
            
        </div><!-- panel panel-default finish -->
    </div><!-- col-lg-12 finish -->
</div><!-- row 2 finish -->

<?php } ?>