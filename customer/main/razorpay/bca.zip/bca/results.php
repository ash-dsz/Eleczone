<?php
include("includes/db.php");
include("includes/header1.php");
if(isset($_GET['submit']))
{
	
	$se=$_GET['user_query'];
	$search="Select * from product_categories WHERE p_cat_title='$se' OR p_cat_desc='$se'";
	$run_product = mysqli_query($con,$search);
		
	$row_product = mysqli_fetch_array($run_product);
	if($row_product>0){
	$p_cat_id = $row_product['p_cat_id'];
	$query="Select * from product WHERE p_cat_id='$p_cat_id' ";
	$run_products = mysqli_query($con,$query);
	
		
		while ($row_product = mysqli_fetch_array($run_products))
		 {
			
		 	 $pro_id = $row_product['product_id'];
        
            $pro_title = $row_product['product_title'];

            $pro_price = $row_product['product_price'];

            $pro_img1 = $row_product['product_img1'];
            
            echo "
            
                <div class='col-md-4 col-sm-6 center-responsive'>
        
            <div class='product'>
            
                <a href='details.php?pro_id=$pro_id'>
                
                    <img class='img-responsive' src='admin_area/product_images/$pro_img1'>
                
                </a>
                
                <div class='text'>
                
                    <h3>
            
                        <a href='details.php?pro_id=$pro_id'>

                            $pro_title

                        </a>
                    
                    </h3>
                    
                    <p class='price'>
                    
                        <i class='fa fa-inr'></i> $pro_price
                    
                    </p>
                    
                    <p class='button'>
                    
                        <a class='btn btn-default' href='details.php?pro_id=$pro_id'>

                            View Details

                        </a>
                    
                        <a class='btn btn-primary' href='details.php?pro_id=$pro_id'>

                            <i class='fa fa-shopping-cart'></i> Add to Cart

                        </a>
                    
                    </p>
                
                </div>
            
            </div>
        
        </div>";


		}
	}
	else
	{
		echo "here";
		echo "<script>alert('No result found')</script>";
		 echo "<script>window.open('index.php','_self')</script>";

	}
	

		include("includes/footer.php");

}
 //echo "<script>window.open('index.php','_self')</script>";
?>