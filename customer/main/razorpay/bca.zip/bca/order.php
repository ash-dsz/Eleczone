<?php 

include("includes/db.php");
include("functions/functions.php");
session_start();
?>
<?php 

if(isset($_GET['c_id'])){
   
    $customer_id = $_GET['c_id'];


$status = "pending";


   
     $customer_email=$_SESSION['customer_email'];
         
        $query="Select * from customers where customer_email='$customer_email'";
        $run_customer = mysqli_query($con,$query);
        $product=mysqli_fetch_array($run_customer);
        $c_id= $product['c_id'];
        $inser_customer=false;
        $status = "pending";
$invoice_no = mt_rand();
         foreach ($_SESSION["cart_item"] as $item)
        {

          $pro_name=$item["name"];
         $p_id =$item['p_id'];
         $qty=$item["quantity"];
         $price=$item["price"];
         $subtotal=$item["subtotal"];
         $insert_customer_order = "insert into customer_orders (customer_id,due_amount,invoice_no,qty,order_date,order_status,product_id) values ('$c_id','$subtotal','$invoice_no','$qty',NOW(),'$status','$p_id')";
        
        $run_customer_order = mysqli_query($con,$insert_customer_order);
        
        $insert_pending_order = "insert into pending_orders (customer_id,invoice_no,product_id,qty,order_status) values ('$c_id','$invoice_no','$p_id','$qty','$status')";
        
        $run_pending_order = mysqli_query($con,$insert_pending_order);

        
        } 
        unset($_SESSION["cart_item"]);
        echo "<script>alert('Your orders has been submitted, Thanks')</script>";
        
        echo "<script>window.open('customer/my_account.php?my_orders','_self')</script>";

 }
?>